const { createClient } = require('@supabase/supabase-js');

// Use the hardcoded Supabase configuration from the app
const supabaseUrl = 'https://gsrzxzrpxtyjddqkperq.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imdzcnp4enJweHR5amRkcWtwZXJxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDIwMjA0MjQsImV4cCI6MjA1NzU5NjQyNH0.hRXbfLbDtkC2Hbh6ZlVJzT-RsgbogZZ_YGeX6FOcYPI';

const supabase = createClient(supabaseUrl, supabaseAnonKey);

async function fixUserProfileIssue() {
  const walletAddress = 'PJEIDDKUOONTJOIV3BLZS7SZSAHCVKNNHTLKMASI6RTYSOZNSDY7MWGZ3M';
  
  console.log('🔍 Checking RLS policies and user profile setup...');
  
  try {
    // First, let's check if we can read from user_profiles table
    console.log('\n1️⃣ Testing read access to user_profiles...');
    const { data: allProfiles, error: readError } = await supabase
      .from('user_profiles')
      .select('wallet_address, credits_balance')
      .limit(5);
    
    if (readError) {
      console.log('❌ Read error:', readError);
    } else {
      console.log('✅ Read access OK. Found', allProfiles.length, 'profiles');
      if (allProfiles.length > 0) {
        console.log('Sample profiles:', allProfiles);
      }
    }
    
    // Check if our specific wallet exists
    console.log('\n2️⃣ Checking for specific wallet...');
    const { data: specificProfile, error: specificError } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('wallet_address', walletAddress);
    
    if (specificError) {
      console.log('❌ Specific wallet check error:', specificError);
    } else {
      if (specificProfile.length > 0) {
        console.log('✅ Wallet profile found:', specificProfile[0]);
        return;
      } else {
        console.log('❌ No profile found for wallet');
      }
    }
    
    // Try using the RPC function instead
    console.log('\n3️⃣ Trying to use add_credit_transaction RPC function to create profile...');
    const { data: rpcResult, error: rpcError } = await supabase.rpc('add_credit_transaction', {
      p_wallet_address: walletAddress,
      p_type: 'initial',
      p_amount: 10,
      p_description: 'Initial credits for wallet setup',
      p_transaction_reference: 'setup_' + Date.now()
    });

    if (rpcError) {
      console.log('❌ RPC function error:', rpcError);
    } else {
      console.log('✅ RPC function worked:', rpcResult);
      
      // Check if profile was created
      const { data: newProfile, error: checkError } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('wallet_address', walletAddress)
        .single();
      
      if (checkError) {
        console.log('❌ Profile check after RPC failed:', checkError);
      } else {
        console.log('✅ Profile created successfully:', newProfile);
      }
    }
    
  } catch (err) {
    console.log('❌ Unexpected error:', err);
  }
}

fixUserProfileIssue();
