const { createClient } = require('@supabase/supabase-js');

// Use the hardcoded Supabase configuration from the app
const supabaseUrl = 'https://gsrzxzrpxtyjddqkperq.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imdzcnp4enJweHR5amRkcWtwZXJxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDIwMjA0MjQsImV4cCI6MjA1NzU5NjQyNH0.hRXbfLbDtkC2Hbh6ZlVJzT-RsgbogZZ_YGeX6FOcYPI';

const supabase = createClient(supabaseUrl, supabaseAnonKey);

async function checkUserProfile() {
  const walletAddress = 'PJEIDDKUOONTJOIV3BLZS7SZSAHCVKNNHTLKMASI6RTYSOZNSDY7MWGZ3M';
  
  console.log('🔍 Checking user profile for wallet:', walletAddress);
  
  try {
    // Check if profile exists
    const { data, error } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('wallet_address', walletAddress);
    
    if (error) {
      console.log('❌ Database error:', error);
      return;
    }
    
    if (data && data.length > 0) {
      console.log('✅ Found user profile:');
      console.log(JSON.stringify(data[0], null, 2));
    } else {
      console.log('❌ No user profile found');
      
      // Try to create one
      console.log('🔧 Creating user profile...');
      const { data: newProfile, error: createError } = await supabase
        .from('user_profiles')
        .insert([{
          wallet_address: walletAddress,
          wallet_type: 'algorand',
          network: 'algorand-mainnet',
          credits_balance: 10,
          total_tokens_created: 0
        }])
        .select()
        .single();
      
      if (createError) {
        console.log('❌ Failed to create profile:', createError);
      } else {
        console.log('✅ Created profile:', newProfile);
      }
    }
    
  } catch (err) {
    console.log('❌ Unexpected error:', err);
  }
}

checkUserProfile();
