'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Menu, X, Wallet, ChevronDown, Copy, Check, AlertTriangle, HelpCircle, CreditCard } from 'lucide-react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useWallet } from '@solana/wallet-adapter-react';
import { WalletMultiButton, useWalletModal } from '@solana/wallet-adapter-react-ui';
import { useAlgorandWallet } from '@/components/providers/AlgorandWalletProvider';
import { ADMIN_WALLET } from '@/lib/solana';
import { isAdmin as checkIsAdmin } from '@/lib/admin-config';
import { useToast } from '@/hooks/use-toast';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { useWalletAuth } from '@/components/providers/WalletAuthProvider';
import MainnetConnectionModal from '@/components/MainnetConnectionModal';
import { SmartWalletModal } from '@/components/SmartWalletModal';
import WalletManagementModal from '@/components/WalletManagementModal';
import SolanaWalletManager from '@/components/SolanaWalletManager';
import { isMobile } from '@/lib/mobile-wallet-utils';
import MobileWalletGuidanceModal from '@/components/MobileWalletGuidanceModal';
import { useWalletConnectionErrors } from '@/hooks/useWalletConnectionErrors';
import MobileWalletDisconnect from '@/components/MobileWalletDisconnect';
import { mobileEducationManager } from '@/lib/mobile-education-events';

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isMoreDropdownOpen, setIsMoreDropdownOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [showWalletOptions, setShowWalletOptions] = useState(false);
  const [copiedAddress, setCopiedAddress] = useState<string | null>(null);
  const [creditsBalance, setCreditsBalance] = useState<number>(0);
  const [isLoadingCredits, setIsLoadingCredits] = useState(false);

  const [showMainnetModal, setShowMainnetModal] = useState<boolean>(false);
  const [showMobileWalletModal, setShowMobileWalletModal] = useState<boolean>(false);
  const [isMobileDevice, setIsMobileDevice] = useState(false);
  
  // Mobile wallet guidance state - ONLY for mobile devices
  const [showMobileGuidance, setShowMobileGuidance] = useState<{
    show: boolean;
    walletType: 'solana' | 'algorand';
    error?: string;
  }>({ show: false, walletType: 'solana' });
  
  const pathname = usePathname();
  const router = useRouter();
  const { toast } = useToast();
  
  // Mobile wallet connection error handler
  const { handleConnectionError } = useWalletConnectionErrors();
  
  // Wallet authentication
  const { 
    isAuthenticated, 
    user, 
    walletAddress, 
    walletType, 
    disconnectWallet,
    getCreditsBalance 
  } = useWalletAuth();
  
  // Solana wallet
  const { connected: solanaConnected, publicKey: solanaPublicKey, disconnect: disconnectSolana } = useWallet();
  const { setVisible: setWalletModalVisible } = useWalletModal();
  
  // Algorand wallet
  const { 
    connected: algorandConnected, 
    address: algorandAddress, 
    connect: connectAlgorand, 
    disconnect: disconnectAlgorand,
    selectedNetwork: algorandSelectedNetwork,
    setSelectedNetwork: setAlgorandSelectedNetwork,
    networkConfig: algorandNetworkConfig,
    isPeraWalletReady,
    isConnecting: algorandIsConnecting
  } = useAlgorandWallet();

  useEffect(() => {
    setMounted(true);
    setIsMobileDevice(isMobile());
    
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Element;
      if (!target.closest('.dropdown-container')) {
        setIsMoreDropdownOpen(false);
        setShowWalletOptions(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    document.addEventListener('click', handleClickOutside);
    handleScroll();
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
      document.removeEventListener('click', handleClickOutside);
    };
  }, []);

  // Load credits balance when wallet connects
  useEffect(() => {
    const loadCreditsBalance = async () => {
      if (!walletAddress || !isAuthenticated) {
        setCreditsBalance(0);
        return;
      }

      setIsLoadingCredits(true);
      try {
        const balance = await getCreditsBalance();
        setCreditsBalance(balance || 0);
      } catch (error) {
        console.error('Error loading credits balance:', error);
        setCreditsBalance(0);
      } finally {
        setIsLoadingCredits(false);
      }
    };

    loadCreditsBalance();
  }, [walletAddress, isAuthenticated, getCreditsBalance]);

  // Listen for mobile education events from wallet components
  useEffect(() => {
    const unsubscribe = mobileEducationManager.subscribe((event) => {
      console.log('📱 Mobile education event received:', event);
      setShowMobileGuidance({
        show: true,
        walletType: event.walletType,
        error: event.error
      });
    });

    return unsubscribe;
  }, []);

  // Core navigation items for desktop
  const coreNavLinks = [
    { name: 'Create Token', href: '/create' },
    { name: 'Dashboard', href: '/dashboard' },
    { name: 'Credits', href: '/credits' },
    // Analytics only for admins - moved to admin-only section
  ];

  // Additional items moved to dropdown
  const additionalNavLinks = [
    { name: 'Tokenomics Simulator', href: '/tokenomics', icon: HelpCircle },
    { name: 'Verify Token', href: '/verify', icon: AlertTriangle },
  ];

  // All links for mobile
  const allNavLinks = [...coreNavLinks, ...additionalNavLinks];

  // Check if user is admin (supports both Algorand and Solana)
  const isAdmin = (solanaConnected && solanaPublicKey && solanaPublicKey.toString() === ADMIN_WALLET.toString()) ||
                  (algorandAddress && checkIsAdmin(algorandAddress));

  // Enhanced navigation with loading state
  const handleNavigation = (href: string, event?: React.MouseEvent) => {
    if (event) {
      event.preventDefault();
    }
    
    // Show loading indicator for dashboard
    if (href === '/dashboard') {
      setIsMenuOpen(false); // Close mobile menu immediately
      // Add loading class to show immediate feedback
      document.body.classList.add('dashboard-loading');
      setTimeout(() => {
        document.body.classList.remove('dashboard-loading');
      }, 3000);
    }
    
    router.push(href);
  };
  
  const handleAlgorandConnect = async () => {
    try {
      await connectAlgorand();
      setShowWalletOptions(false);
    } catch (error: any) {
      console.error('Failed to connect Algorand wallet:', error);
      
      // Check if this is a mobile connection error that needs guidance
      if (handleConnectionError(error, 'algorand')) {
        console.log('📱 Showing mobile guidance for Algorand wallet');
        setShowMobileGuidance({
          show: true,
          walletType: 'algorand',
          error: error.message
        });
        return;
      }
      
      // Show the modal for mainnet connection issues
      if (algorandSelectedNetwork === 'algorand-mainnet') {
        setShowMainnetModal(true);
      } else {
        toast({
          title: "Connection Failed",
          description: error instanceof Error ? error.message : "Failed to connect to Algorand wallet. Please try again.",
          variant: "destructive",
        });
      }
    }
  };

  const handleAlgorandDisconnect = async () => {
    try {
      await disconnectAlgorand();
    } catch (error) {
      console.error('Failed to disconnect Algorand wallet:', error);
    }
  };

  const copyToClipboard = async (address: string, walletType: string) => {
    try {
      await navigator.clipboard.writeText(address);
      setCopiedAddress(address);
      
      setTimeout(() => {
        setCopiedAddress(null);
      }, 2000);
    } catch (error) {
      console.error('Failed to copy address:', error);
    }
  };

  const formatAddress = (address: string) => {
    if (address.length <= 12) return address;
    return `${address.slice(0, 4)}...${address.slice(-4)}`;
  };

  // Don't render until mounted to avoid hydration issues
  if (!mounted) {
    return (
      <div className="fixed top-0 left-0 right-0 z-50 h-16 bg-background border-b border-border">
        <div className="flex items-center justify-center h-full">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-red-500"></div>
        </div>
      </div>
    );
  }

  const isAnyWalletConnected = solanaConnected || algorandConnected;

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled 
        ? 'backdrop-blur-xl border-b shadow-lg' 
        : 'backdrop-blur-sm border-b'
    }`} 
         style={{
           backgroundColor: isScrolled 
             ? 'rgba(0, 0, 0, 0.95)'
             : 'rgba(0, 0, 0, 0.8)',
           borderColor: 'rgb(31, 41, 55)'
         }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center group">
            <div className="flex items-center space-x-2">
              <img 
                src="/logo.png" 
                alt="Snarbles Logo" 
                className="w-8 h-8 rounded-lg object-contain"
              />
              <span className="text-2xl font-bold text-foreground group-hover:text-red-500 transition-colors">
                Snarbles
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {/* Core Navigation Links */}
            {coreNavLinks.map((link) => (
              <Link
                key={link.name}
                href={link.href}
                onClick={(e) => {
                  handleNavigation(link.href, e);
                }}
                className={`text-muted-foreground hover:text-foreground transition-all duration-200 font-medium relative group ${
                  pathname === link.href ? 'text-red-500' : ''
                }`}
              >
                {link.name}
                <div className={`absolute -bottom-1 left-0 h-0.5 bg-red-500 transition-all duration-300 ${
                  pathname === link.href ? 'w-full' : 'w-0 group-hover:w-full'
                }`}></div>
              </Link>
            ))}
            
            {/* More Dropdown */}
            <div className="relative dropdown-container">
              <Button
                variant="ghost"
                onClick={() => setIsMoreDropdownOpen(!isMoreDropdownOpen)}
                className="text-muted-foreground hover:text-foreground transition-all duration-200 font-medium relative group"
              >
                More
                <ChevronDown className="w-4 h-4 ml-1" />
                <div className={`absolute -bottom-1 left-0 h-0.5 bg-red-500 transition-all duration-300 ${
                  additionalNavLinks.some(link => pathname === link.href) ? 'w-full' : 'w-0 group-hover:w-full'
                }`}></div>
              </Button>
              
              {isMoreDropdownOpen && (
                <div className="absolute right-0 top-full mt-2 w-56 bg-background/95 backdrop-blur-xl border border-border rounded-xl shadow-2xl z-50 animate-in slide-in-from-top-2 duration-200 overflow-hidden">
                  <div className="p-2">
                    {additionalNavLinks.map((link) => (
                      <Link
                        key={link.name}
                        href={link.href}
                        onClick={(e) => {
                          handleNavigation(link.href, e);
                          setIsMoreDropdownOpen(false);
                        }}
                        className={`flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                          pathname === link.href 
                            ? 'bg-red-500/10 text-red-500' 
                            : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                        }`}
                      >
                        <link.icon className="w-4 h-4" />
                        <span>{link.name}</span>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
            
            {/* Admin Link */}
            {isAdmin && (
              <>
                <Link
                  href="/admin"
                  className={`text-muted-foreground hover:text-foreground transition-all duration-200 font-medium relative group ${
                    pathname === '/admin' ? 'text-red-500' : ''
                  }`}
                >
                  Admin
                  <div className={`absolute -bottom-1 left-0 h-0.5 bg-red-500 transition-all duration-300 ${
                    pathname === '/admin' ? 'w-full' : 'w-0 group-hover:w-full'
                  }`}></div>
                </Link>
              </>
            )}
          </div>

          {/* Desktop Controls */}
          <div className="hidden md:flex items-center space-x-4">
            {/* Credits Balance Display */}
            {isAuthenticated && (
              <Link 
                href="/credits"
                className="flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/20 hover:border-primary/40 transition-all duration-200 group"
              >
                <CreditCard className="w-4 h-4 text-primary" />
                <span className="text-foreground font-medium text-sm">
                  {isLoadingCredits ? (
                    <div className="flex items-center">
                      <div className="w-3 h-3 border-2 border-primary border-t-transparent rounded-full animate-spin mr-1"></div>
                      Loading...
                    </div>
                  ) : (
                    `${creditsBalance} Credits`
                  )}
                </span>
              </Link>
            )}
            
            {/* Enhanced Multi-Wallet Connection */}
            <div className="relative dropdown-container">
              {isAnyWalletConnected ? (
                <div className="flex items-center space-x-2">
                  <div className="wallet-status-connected rounded-full px-3 py-1.5">
                    <div 
                      className="flex items-center space-x-2 px-3 cursor-pointer"
                      onClick={() => setShowWalletOptions(!showWalletOptions)}
                    >
                      <div className="flex items-center space-x-2">
                        {solanaConnected && (
                          <div className="flex items-center">
                            <div className="w-6 h-6 rounded-full flex items-center justify-center bg-[#AB9FF2] wallet-pulse-indicator">
                              <span className="text-white font-bold text-xs">S</span>
                            </div>
                          </div>
                        )}
                        
                        {algorandConnected && (
                          <div className="flex items-center">
                            <div className="w-6 h-6 rounded-full flex items-center justify-center bg-[#22C55E] wallet-pulse-indicator">
                              <span className="text-white font-bold text-xs">A</span>
                            </div>
                          </div>
                        )}
                        
                        <span className="text-foreground font-medium text-sm wallet-status-enhanced">
                          {solanaConnected && algorandConnected
                            ? "2 Wallets"
                            : solanaConnected
                              ? formatAddress(solanaPublicKey!.toString())
                              : formatAddress(algorandAddress!)}
                        </span>
                        
                        <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Wallet Options Button */}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setShowWalletOptions(!showWalletOptions);
                      // Play subtle wallet animation for feedback
                      const walletBtns = document.querySelectorAll('.wallet-pulse-indicator');
                      walletBtns.forEach(btn => {
                        btn.classList.add('animate-pulse');
                        setTimeout(() => btn.classList.remove('animate-pulse'), 800);
                      });
                    }}
                    className="border-border/70 text-muted-foreground hover:bg-muted/70 rounded-lg p-1.5"
                  >
                    <ChevronDown className="w-3 h-3" />
                  </Button>
                </div>
              ) : (
                <Button
                  onClick={() => {
                    if (isMobileDevice) {
                      setShowMobileWalletModal(true);
                    } else {
                      setShowWalletOptions(!showWalletOptions);
                    }
                  }}
                  className="wallet-connect-button bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-semibold rounded-xl px-4 py-2 h-9 shadow-lg hover:shadow-xl transition-all duration-200"
                >
                  <Wallet className="w-4 h-4 mr-2" />
                  <span className="relative z-10">Connect Wallet</span>
                </Button>
              )}

              {/* Enhanced Wallet Options Dropdown */}
              {showWalletOptions && (
                <div className="absolute right-0 top-full mt-2 w-80 bg-background/95 backdrop-blur-xl border border-border rounded-xl shadow-2xl z-50 animate-in slide-in-from-top-2 duration-200 overflow-hidden">
                  <div className="p-4 relative overflow-visible">
                    {/* Background decoration */}
                    <div className="absolute -top-24 -right-24 w-48 h-48 bg-red-500/5 rounded-full blur-3xl"></div>
                    <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-blue-500/5 rounded-full blur-3xl"></div>

                    <div className="mb-4 text-center">
                      <h3 className="text-foreground font-bold text-lg mb-1 gradient-text">Wallet Management</h3>
                      <p className="text-muted-foreground text-xs">Connect or manage your wallets</p>
                    </div>
                    
                    {/* Wallet Cards Container */}
                    <div className="grid grid-cols-1 gap-3">
                      {/* Solana Wallet Card */}
                      <div className="rounded-lg overflow-hidden border border-[#9945FF]/20 shadow-sm">
                        <div className="bg-[#9945FF]/10 p-3">
                          <div className="flex items-center space-x-2">
                            <div className="w-8 h-8 rounded-full bg-[#9945FF] flex items-center justify-center shadow-md">
                              <span className="text-white font-bold text-xs">S</span>
                            </div>
                            <div>
                              <p className="text-foreground font-medium text-sm">Solana Wallet</p>
                              <p className="text-muted-foreground text-xs">For Solana Network tokens</p>
                            </div>
                            
                            {solanaConnected && (
                              <div className="ml-auto flex items-center space-x-1">
                                <span className="flex items-center text-green-500 text-xs font-medium">
                                  <span className="w-1.5 h-1.5 bg-green-500 rounded-full mr-1"></span>
                                  Connected
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="p-3 space-y-2">
                          {solanaConnected && solanaPublicKey && (
                            <div className="space-y-2">
                              {/* Wallet Address Display */}
                              <div className="flex items-center justify-between p-2 bg-[#9945FF]/5 border border-[#9945FF]/20 rounded-md">
                                <p className="text-[#9945FF] text-xs font-mono">{formatAddress(solanaPublicKey.toString())}</p>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => copyToClipboard(solanaPublicKey.toString(), 'Solana')}
                                  className="h-6 w-6 p-0"
                                  title="Copy full address"
                                >
                                  {copiedAddress === solanaPublicKey.toString() ? (
                                    <Check className="w-3 h-3 text-green-500" />
                                  ) : (
                                    <Copy className="w-3 h-3 text-[#9945FF]" />
                                  )}
                                </Button>
                              </div>
                              
                              {/* Network Status */}
                              <div className="p-2 bg-[#9945FF]/5 border border-[#9945FF]/20 rounded-md">
                                <div className="flex justify-between items-center">
                                  <span className="text-xs text-[#9945FF]">Network Status:</span>
                                  <div className="flex items-center">
                                    <span className="h-1.5 w-1.5 rounded-full bg-green-500 mr-1"></span>
                                    <span className="text-xs text-green-500">Connected</span>
                                  </div>
                                </div>
                              </div>
                              
                              {/* Credits Management Button */}
                              <Button
                                onClick={() => {
                                  handleNavigation('/credits');
                                  setShowWalletOptions(false);
                                }}
                                variant="outline"
                                size="sm"
                                className="w-full border-blue-500/20 text-blue-400 hover:bg-blue-500/10 hover:border-blue-500/40 text-xs h-8"
                              >
                                <CreditCard className="w-3 h-3 mr-2" />
                                Manage Credits
                              </Button>
                              
                              {/* Disconnect Button */}
                              <Button
                                onClick={async () => {
                                  try {
                                    // Show loading state
                                    toast({
                                      title: "Disconnecting Solana wallet...",
                                      duration: 1500
                                    });
                                    
                                    // Perform disconnect
                                    await disconnectSolana();
                                    setShowWalletOptions(false);
                                    
                                    // Success feedback
                                    toast({
                                      title: "Solana wallet disconnected",
                                      description: "Successfully disconnected from Solana wallet",
                                      duration: 2000
                                    });
                                  } catch (err) {
                                    console.error("Solana disconnect error:", err);
                                    toast({
                                      title: "Disconnect failed",
                                      description: "Failed to disconnect Solana wallet",
                                      variant: "destructive",
                                      duration: 3000
                                    });
                                  }
                                }}
                                variant="outline"
                                size="sm"
                                className="w-full border-red-500/20 text-red-500 hover:bg-red-500/10 hover:border-red-500/40 text-xs h-8"
                              >
                                Disconnect Solana
                              </Button>
                            </div>
                          )}
                          {(!solanaConnected || !solanaPublicKey) && (
                            <div>
                              <Button
                                onClick={() => {
                                  try {
                                    // Trigger the standard Solana wallet modal
                                    setWalletModalVisible(true);
                                    setShowWalletOptions(false);
                                  } catch (error: any) {
                                    console.log('🔍 Solana wallet connection error:', error);
                                    
                                    // Check if this is a mobile connection error that needs guidance
                                    if (handleConnectionError(error, 'solana')) {
                                      console.log('📱 Showing mobile guidance for Solana wallet');
                                      setShowMobileGuidance({
                                        show: true,
                                        walletType: 'solana',
                                        error: error.message
                                      });
                                    } else {
                                      // Standard error handling for non-mobile or other errors
                                      toast({
                                        title: "Connection Failed",
                                        description: error.message || "Failed to connect Solana wallet",
                                        variant: "destructive"
                                      });
                                    }
                                  }
                                }}
                                className="w-full button-enhanced py-2 text-sm"
                              >
                                <Wallet className="w-4 h-4 mr-2" />
                                Connect Solana Wallet
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      {/* Algorand Wallet Card */}
                      <div className="rounded-lg overflow-hidden border border-[#ffee55]/20 shadow-sm">
                        <div className="bg-[#ffee55]/10 p-3">
                          <div className="flex items-center space-x-2">
                            <div className="w-8 h-8 rounded-full bg-[#ffee55] flex items-center justify-center shadow-md relative">
                              <span className="text-black font-bold text-xs">A</span>
                              <div className="absolute -inset-1 bg-[#ffee55]/30 rounded-full animate-pulse opacity-75"></div>
                            </div>
                            <div>
                              <p className="text-foreground font-medium text-sm">Algorand Wallet</p>
                              <p className="text-muted-foreground text-xs">For Algorand Network tokens</p>
                            </div>
                            
                            {algorandConnected && (
                              <div className="ml-auto flex items-center space-x-1">
                                <span className="flex items-center text-green-500 text-xs font-medium">
                                  <span className="w-1.5 h-1.5 bg-green-500 rounded-full mr-1"></span>
                                  Connected
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="p-3 space-y-2">
                          {algorandConnected && algorandAddress && (
                            <>
                              <div className="space-y-2">
                                {/* Wallet Address Display */}
                                <div className="flex items-center justify-between p-2 bg-[#ffee55]/5 border border-[#ffee55]/20 rounded-md overflow-hidden">
                                  <p className="text-[#ffee55] text-xs font-mono break-all">{formatAddress(algorandAddress)}</p>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => copyToClipboard(algorandAddress, 'Algorand')}
                                    className="h-6 w-6 p-0"
                                    title="Copy full address"
                                  >
                                    {copiedAddress === algorandAddress ? (
                                      <Check className="w-3 h-3 text-green-500" />
                                    ) : (
                                      <Copy className="w-3 h-3 text-[#ffee55]" />
                                    )}
                                  </Button>
                                </div>
                                
                                <div className="p-2 bg-[#ffee55]/5 border border-[#ffee55]/20 rounded-md">
                                  <div className="flex justify-between items-center">
                                    <span className="text-xs text-[#ffee55]">Network Status:</span>
                                    <div className="flex items-center">
                                      <span className="h-1.5 w-1.5 rounded-full bg-green-500 mr-1"></span>
                                      <span className="text-xs text-green-500">Connected</span>
                                    </div>
                                  </div>
                                </div>
                                
                                {/* Credits Management Button */}
                                <Button
                                  onClick={() => {
                                    handleNavigation('/credits');
                                    setShowWalletOptions(false);
                                  }}
                                  variant="outline"
                                  size="sm"
                                  className="w-full border-blue-500/20 text-blue-400 hover:bg-blue-500/10 hover:border-blue-500/40 text-xs h-8"
                                >
                                  <CreditCard className="w-3 h-3 mr-2" />
                                  Manage Credits
                                </Button>
                                
                                {/* Disconnect Button */}
                                <Button
                                  onClick={async () => {
                                    try {
                                      // Show loading state
                                      toast({
                                        title: "Disconnecting wallet...",
                                        duration: 1500
                                      });
                                      
                                      // Perform disconnect
                                      await handleAlgorandDisconnect();
                                      setShowWalletOptions(false);
                                    } catch (err) {
                                      console.error("Disconnect error:", err);
                                    }
                                  }}
                                  variant="outline"
                                  size="sm"
                                  className="w-full border-red-500/20 text-red-500 hover:bg-red-500/10 hover:border-red-500/40 text-xs h-8"
                                >
                                  Disconnect
                                </Button>
                              </div>
                            </>
                          )}
                          
                          {!algorandConnected && (
                            <div className="space-y-2">
                              {!isPeraWalletReady && (
                                <div className="flex items-center p-2 bg-yellow-500/10 border border-yellow-500/20 rounded-md">
                                  <AlertTriangle className="w-3 h-3 text-yellow-500 mr-1 flex-shrink-0" />
                                  <p className="text-yellow-600 dark:text-yellow-400 text-xs">
                                    Pera Wallet extension not detected. Please install to connect.
                                  </p>
                                </div>
                              )}
                              
                              <Button
                                onClick={handleAlgorandConnect}
                                disabled={!isPeraWalletReady || algorandIsConnecting}
                                className="w-full button-enhanced py-2 text-sm"
                              >
                                {algorandIsConnecting ? (
                                  <div className="flex items-center justify-center">
                                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                                    <span>Connecting...</span>
                                  </div>
                                ) : (
                                  <>
                                    <Wallet className="w-4 h-4 mr-2" />
                                    Connect Pera Wallet
                                  </>
                                )}
                              </Button>
                              
                              {/* Help link */}
                              <a 
                                href="https://perawallet.app/download/" 
                                target="_blank" 
                                rel="noreferrer" 
                                className="text-xs text-center block text-[#22C55E] hover:underline"
                              >
                                Need to install Pera Wallet?
                              </a>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    {/* Close button */}
                    <div className="flex justify-end mt-3">
                      <Button
                        onClick={() => setShowWalletOptions(false)}
                        variant="ghost"
                        size="sm"
                        className="text-muted-foreground hover:text-foreground text-xs"
                      >
                        Close
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              {/* Click outside to close - but don't interfere with wallet modal */}
              {showWalletOptions && (
                <div 
                  className="fixed inset-0 z-40"
                  onClick={(e) => {
                    // Don't close if clicking on wallet adapter modal elements
                    if (e.target instanceof HTMLElement && 
                        (e.target.closest('.wallet-adapter-modal') || 
                         e.target.closest('.wallet-adapter-dropdown'))) {
                      return;
                    }
                    setShowWalletOptions(false);
                  }}
                />
              )}

            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-muted-foreground hover:text-foreground hover:bg-muted/50 rounded-xl p-2"
            >
              {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 border-t border-border mt-4">
              {allNavLinks.map((link) => (
                <Link
                  key={link.name}
                  href={link.href}
                  onClick={() => {
                    handleNavigation(link.href);
                    setIsMenuOpen(false);
                  }}
                  className={`block px-3 py-2 text-base font-medium rounded-lg transition-colors ${
                    pathname === link.href
                      ? 'text-red-500 bg-red-500/10'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                  }`}
                >
                  {link.name}
                </Link>
              ))}
              
              {/* Mobile Credits Display */}
              {isAuthenticated && (
                <div className="px-3 py-2">
                  <Link 
                    href="/credits"
                    onClick={() => setIsMenuOpen(false)}
                    className="flex items-center space-x-3 p-3 rounded-lg bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/20"
                  >
                    <CreditCard className="w-5 h-5 text-primary" />
                    <div className="flex flex-col">
                      <span className="text-sm font-medium text-foreground">
                        {isLoadingCredits ? 'Loading Credits...' : `${creditsBalance} Credits`}
                      </span>
                      <span className="text-xs text-muted-foreground">Available Balance</span>
                    </div>
                    {isLoadingCredits && (
                      <div className="w-3 h-3 border-2 border-primary border-t-transparent rounded-full animate-spin ml-auto"></div>
                    )}
                  </Link>
                </div>
              )}
              
              {/* Admin Links - Mobile */}
              {isAdmin && (
                <>
                  <Link
                    href="/admin"
                    onClick={() => setIsMenuOpen(false)}
                    className={`block px-3 py-2 text-base font-medium rounded-lg transition-colors ${
                      pathname === '/admin'
                        ? 'text-red-500 bg-red-500/10'
                        : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                    }`}
                  >
                    Admin
                  </Link>
                </>
              )}
              
              {/* Mobile Wallet Connection */}
              <div className="px-3 py-2 space-y-3">
                {!isAnyWalletConnected ? (
                  <Button
                    onClick={() => {
                      if (isMobileDevice) {
                        setShowMobileWalletModal(true);
                      } else {
                        setShowWalletOptions(!showWalletOptions);
                      }
                      setIsMenuOpen(false);
                    }}
                    className="w-full bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-semibold rounded-xl px-4 py-2 shadow-lg hover:shadow-xl transition-all duration-200"
                  >
                    <Wallet className="w-4 h-4 mr-2" />
                    Connect Wallet
                  </Button>
                ) : (
                  <div className="space-y-3">
                    {/* Solana Wallet Display with Disconnect */}
                    {solanaConnected && solanaPublicKey && (
                      <MobileWalletDisconnect
                        walletType="solana"
                        walletAddress={solanaPublicKey.toString()}
                        onDisconnect={async () => {
                          await disconnectSolana();
                          setIsMenuOpen(false);
                        }}
                        isConnected={solanaConnected}
                      />
                    )}
                    
                    {/* Algorand Wallet Display with Disconnect */}
                    {algorandConnected && algorandAddress && (
                      <MobileWalletDisconnect
                        walletType="algorand"
                        walletAddress={algorandAddress}
                        onDisconnect={async () => {
                          await handleAlgorandDisconnect();
                          setIsMenuOpen(false);
                        }}
                        isConnected={algorandConnected}
                      />
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Mainnet Connection Modal */}
      <MainnetConnectionModal 
        isOpen={showMainnetModal} 
        onClose={() => setShowMainnetModal(false)} 
      />
      
      {/* Mobile Wallet Modal */}
      <WalletManagementModal
        isOpen={showMobileWalletModal}
        onClose={() => setShowMobileWalletModal(false)}
      />
      
      {/* Mobile Wallet Guidance Modal - ONLY for mobile devices */}
      <MobileWalletGuidanceModal
        isOpen={showMobileGuidance.show}
        onClose={() => setShowMobileGuidance({ show: false, walletType: 'solana' })}
        walletType={showMobileGuidance.walletType}
        error={showMobileGuidance.error}
      />
    </nav>
  );
}