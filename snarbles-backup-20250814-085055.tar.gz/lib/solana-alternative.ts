import { 
  Connection, 
  PublicKey, 
  Keypair, 
  Transaction, 
  SystemProgram,
  LAMPORTS_PER_SOL,
  ParsedAccountData 
} from '@solana/web3.js';
import { 
  TOKEN_PROGRAM_ID, 
  ASSOCIATED_TOKEN_PROGRAM_ID,
  createInitializeMintInstruction,
  createAssociatedTokenAccountInstruction,
  createMintToInstruction,
  createSetAuthorityInstruction,
  getMinimumBalanceForRentExemptMint,
  getAssociatedTokenAddress,
  AuthorityType,
  MINT_SIZE
} from '@solana/spl-token';
import { CURRENT_SOLANA_NETWORK } from './solana-data';

// Use the existing connection from solana.ts
import { connection } from './solana';

// Import mobile-optimized functions
import { 
  createSolanaTokenMobile, 
  detectMobileWalletEnvironment,
  validateMobileWalletForSolana,
  MobileWalletInterface
} from './solana-mobile-optimized';

// Import enhanced creation with metadata
import { createSolanaTokenWithMetadata } from './solana-enhanced-creation';

// Alternative token creation using standard Solana token program
export async function createSolanaTokenDirect(
  wallet: { publicKey: PublicKey; signTransaction: (txn: any) => Promise<any> },
  tokenData: {
    name: string;
    symbol: string;
    description: string;
    decimals: number;
    totalSupply: number;
    logoUrl: string;
    website?: string;
    github?: string;
    twitter?: string;
    mintable: boolean;
    burnable: boolean;
    pausable: boolean;
  },
  options?: {
    onStepUpdate?: (step: string, status: string, details?: any) => void;
  }
) {
  try {
    const { onStepUpdate } = options || {};
    
    // Try enhanced creation with metadata first
    if (onStepUpdate) {
      onStepUpdate('method-selection', 'in-progress', { 
        message: 'Using enhanced token creation with metadata...' 
      });
    }

    try {
      const result = await createSolanaTokenWithMetadata(wallet, tokenData, options);
      
      if (result.success) {
        console.log('✅ Enhanced token creation successful');
        return result;
      } else {
        console.warn('Enhanced creation failed, falling back to basic method:', result);
      }
    } catch (enhancedError) {
      console.warn('Enhanced creation error, falling back to basic method:', enhancedError);
    }

    // Fallback to basic creation if enhanced fails
    if (onStepUpdate) {
      onStepUpdate('method-selection', 'in-progress', { 
        message: 'Using fallback basic token creation...' 
      });
    }

    // Detect mobile environment
    const environment = detectMobileWalletEnvironment();
    
    if (onStepUpdate) {
      onStepUpdate('environment-check', 'in-progress', { 
        message: `Detected ${environment.isMobile ? 'mobile' : 'desktop'} environment`,
        environment 
      });
    }

    // Use mobile-optimized creation if on mobile
    if (environment.isMobile) {
      if (onStepUpdate) {
        onStepUpdate('mobile-optimization', 'in-progress', { 
          message: 'Using mobile-optimized token creation...' 
        });
      }

      // Validate mobile wallet readiness
      const validation = validateMobileWalletForSolana();
      if (!validation.isReady) {
        throw new Error(`Mobile wallet not ready: ${validation.issues.join(', ')}. ${validation.recommendations.join(' ')}`);
      }

      // Convert wallet interface for mobile optimization
      const mobileWallet: MobileWalletInterface = {
        publicKey: wallet.publicKey,
        signTransaction: wallet.signTransaction,
        isPhantom: !!(window as any).phantom?.solana?.isPhantom,
        isOKX: !!(window as any).okxwallet?.solana,
        isMobile: true
      };

      const result = await createSolanaTokenMobile(
        mobileWallet,
        tokenData,
        (step: string, message: string, details?: any) => {
          if (onStepUpdate) {
            onStepUpdate(step, 'in-progress', { message, details });
          }
        }
      );

      if (result.success) {
        if (onStepUpdate) {
          onStepUpdate('success', 'completed', { 
            message: 'Token created successfully on mobile!',
            signature: result.signature,
            mintAddress: result.mintAddress
          });
        }

        return {
          success: true,
          mintAddress: result.mintAddress,
          signature: result.signature,
          tokenAccount: result.tokenAccount,
          metadata: {
            name: tokenData.name,
            symbol: tokenData.symbol,
            description: tokenData.description,
            image: tokenData.logoUrl,
            external_url: tokenData.website,
            properties: {
              files: tokenData.logoUrl ? [{ uri: tokenData.logoUrl, type: 'image' }] : [],
              category: 'token',
              decimals: tokenData.decimals,
              total_supply: tokenData.totalSupply,
              mintable: tokenData.mintable,
              burnable: tokenData.burnable
            }
          }
        };
      } else {
        throw new Error(result.error || 'Mobile token creation failed');
      }
    }

    // Fall back to basic desktop version
    if (onStepUpdate) {
      onStepUpdate('desktop-fallback', 'in-progress', { 
        message: 'Using basic desktop token creation...' 
      });
    }
    
    if (onStepUpdate) {
      onStepUpdate('wallet-check', 'in-progress', { message: 'Validating wallet...' });
    }

    // Validate wallet
    if (!wallet || !wallet.publicKey) {
      throw new Error('Wallet not connected');
    }

    // Check SOL balance
    const balance = await connection.getBalance(wallet.publicKey);
    const solBalance = balance / LAMPORTS_PER_SOL;
    
    if (solBalance < 0.01) {
      throw new Error(`Insufficient SOL balance (${solBalance.toFixed(4)} SOL). Need at least 0.01 SOL for transaction fees.`);
    }

    if (onStepUpdate) {
      onStepUpdate('wallet-check', 'completed', { 
        message: `Wallet validated. Balance: ${solBalance.toFixed(4)} SOL` 
      });
      onStepUpdate('token-setup', 'in-progress', { message: 'Setting up token accounts...' });
    }

    // Generate new mint keypair
    const mintKeypair = Keypair.generate();
    
    // Calculate rent for mint account
    const mintRent = await getMinimumBalanceForRentExemptMint(connection);
    
    // Get associated token account
    const tokenAccount = await getAssociatedTokenAddress(
      mintKeypair.publicKey,
      wallet.publicKey
    );

    if (onStepUpdate) {
      onStepUpdate('token-setup', 'completed', { 
        message: `Mint address: ${mintKeypair.publicKey.toString()}` 
      });
      onStepUpdate('transaction-build', 'in-progress', { message: 'Building transaction...' });
    }

    // Calculate initial supply (with decimals)
    const initialSupply = Number(tokenData.totalSupply) * Math.pow(10, tokenData.decimals);
    
    // Create transaction
    const transaction = new Transaction();

    // Add create mint account instruction
    transaction.add(
      SystemProgram.createAccount({
        fromPubkey: wallet.publicKey,
        newAccountPubkey: mintKeypair.publicKey,
        space: MINT_SIZE,
        lamports: mintRent,
        programId: TOKEN_PROGRAM_ID,
      })
    );

    // Add initialize mint instruction
    // Properly implement token features for Solana:
    // - mintable: If false, mint authority will be set to null after initial mint (no more minting allowed)
    // - pausable: If true, set freeze authority to wallet (can freeze accounts)
    // - burnable: Always allowed in Solana (token holders can burn their own tokens)
    transaction.add(
      createInitializeMintInstruction(
        mintKeypair.publicKey,
        tokenData.decimals,
        wallet.publicKey, // Initially set mint authority to create initial supply
        tokenData.pausable ? wallet.publicKey : null, // freeze authority (null = no freezing)
        TOKEN_PROGRAM_ID
      )
    );

    // Add create associated token account instruction
    transaction.add(
      createAssociatedTokenAccountInstruction(
        wallet.publicKey, // payer
        tokenAccount, // associated token account
        wallet.publicKey, // owner
        mintKeypair.publicKey, // mint
        TOKEN_PROGRAM_ID,
        ASSOCIATED_TOKEN_PROGRAM_ID
      )
    );

    // Add mint to instruction for initial supply
    if (initialSupply > 0) {
      transaction.add(
        createMintToInstruction(
          mintKeypair.publicKey, // mint
          tokenAccount, // destination
          wallet.publicKey, // authority
          initialSupply, // amount
          [], // signers (empty for single signer)
          TOKEN_PROGRAM_ID
        )
      );
    }

    // If token is not mintable, we need to revoke mint authority after initial mint
    // This will be done in a separate transaction to ensure proper feature implementation
    const needsSecondTransaction = !tokenData.mintable;

    // Get recent blockhash
    const latestBlockhash = await connection.getLatestBlockhash();
    transaction.recentBlockhash = latestBlockhash.blockhash;
    transaction.feePayer = wallet.publicKey;

    // Sign with mint keypair
    transaction.partialSign(mintKeypair);

    if (onStepUpdate) {
      onStepUpdate('transaction-build', 'completed', { 
        message: 'Transaction built successfully' 
      });
      onStepUpdate('wallet-approval', 'in-progress', { message: 'Requesting wallet approval...' });
    }

    // Sign with wallet
    const signedTransaction = await wallet.signTransaction(transaction);

    if (onStepUpdate) {
      onStepUpdate('wallet-approval', 'completed', { message: 'Transaction signed' });
      onStepUpdate('blockchain-submit', 'in-progress', { message: 'Submitting to blockchain...' });
    }

    // Send transaction
    const signature = await connection.sendRawTransaction(signedTransaction.serialize());

    if (onStepUpdate) {
      onStepUpdate('blockchain-submit', 'in-progress', { 
        message: 'Transaction submitted. Awaiting confirmation...' 
      });
    }

    // Confirm transaction with extended timeout
    const confirmation = await connection.confirmTransaction({
      signature: signature,
      blockhash: latestBlockhash.blockhash,
      lastValidBlockHeight: latestBlockhash.lastValidBlockHeight
    }, 'confirmed');

    if (confirmation.value.err) {
      throw new Error(`Transaction failed: ${confirmation.value.err}`);
    }

    if (onStepUpdate) {
      onStepUpdate('blockchain-submit', 'completed', { 
        message: 'Transaction confirmed successfully' 
      });
    }

    // If token is not mintable, revoke mint authority in a second transaction
    if (needsSecondTransaction) {
      if (onStepUpdate) {
        onStepUpdate('revoke-authority', 'in-progress', { 
          message: 'Revoking mint authority (making token non-mintable)...' 
        });
      }

      try {
        const revokeTransaction = new Transaction();
        
        // Add instruction to set mint authority to null (revoke minting capability)
        revokeTransaction.add(
          createSetAuthorityInstruction(
            mintKeypair.publicKey, // mint
            wallet.publicKey, // current authority
            AuthorityType.MintTokens, // authority type
            null, // new authority (null = revoke)
            [], // signers
            TOKEN_PROGRAM_ID
          )
        );

        // Get recent blockhash for second transaction
        const latestBlockhash2 = await connection.getLatestBlockhash();
        revokeTransaction.recentBlockhash = latestBlockhash2.blockhash;
        revokeTransaction.feePayer = wallet.publicKey;

        // Sign and send revoke transaction
        const signedRevokeTransaction = await wallet.signTransaction(revokeTransaction);
        const revokeSignature = await connection.sendRawTransaction(signedRevokeTransaction.serialize());

        // Confirm revoke transaction
        const revokeConfirmation = await connection.confirmTransaction({
          signature: revokeSignature,
          blockhash: latestBlockhash2.blockhash,
          lastValidBlockHeight: latestBlockhash2.lastValidBlockHeight
        }, 'confirmed');

        if (revokeConfirmation.value.err) {
          console.warn('Failed to revoke mint authority:', revokeConfirmation.value.err);
          // Don't fail the whole process, just warn the user
        } else {
          if (onStepUpdate) {
            onStepUpdate('revoke-authority', 'completed', { 
              message: 'Mint authority revoked - token is now non-mintable' 
            });
          }
        }
      } catch (revokeError) {
        console.warn('Failed to revoke mint authority:', revokeError);
        // Don't fail the whole process, just log the warning
        if (onStepUpdate) {
          onStepUpdate('revoke-authority', 'warning', { 
            message: 'Warning: Could not revoke mint authority. Token may still be mintable.' 
          });
        }
      }
    }

    if (onStepUpdate) {
      onStepUpdate('metadata-upload', 'in-progress', { message: 'Creating token metadata...' });
    }

    // Create metadata object (for off-chain storage)
    const metadata = {
      name: tokenData.name,
      symbol: tokenData.symbol,
      description: tokenData.description,
      image: tokenData.logoUrl,
      external_url: tokenData.website,
      properties: {
        files: tokenData.logoUrl ? [{ uri: tokenData.logoUrl, type: 'image' }] : [],
        category: 'image',
        creators: [{
          address: wallet.publicKey.toString(),
          share: 100
        }]
      },
      attributes: [
        { trait_type: 'Decimals', value: tokenData.decimals },
        { trait_type: 'Total Supply', value: tokenData.totalSupply },
        { trait_type: 'Mintable', value: tokenData.mintable, description: 'Mint authority revoked if false' },
        { trait_type: 'Burnable', value: true, description: 'Token holders can always burn their own tokens' },
        { trait_type: 'Pausable', value: tokenData.pausable, description: 'Freeze authority set if true' },
        { trait_type: 'Network', value: CURRENT_SOLANA_NETWORK.name },
        { trait_type: 'Created By', value: 'Snarbles Token Platform' }
      ],
      collection: {
        name: 'Snarbles Tokens',
        family: 'Snarbles'
      }
    };

    if (onStepUpdate) {
      onStepUpdate('metadata-upload', 'completed', { message: 'Metadata created' });
    }

    // Generate explorer URL
    const explorerUrl = `${CURRENT_SOLANA_NETWORK.explorerUrl}/address/${mintKeypair.publicKey.toString()}`;

    return {
      success: true,
      signature,
      mintAddress: mintKeypair.publicKey.toString(),
      tokenAccount: tokenAccount.toString(),
      explorerUrl,
      metadata,
      network: CURRENT_SOLANA_NETWORK.name,
      decimals: tokenData.decimals,
      initialSupply: tokenData.totalSupply,
      features: {
        mintable: tokenData.mintable, // Implemented via mint authority (revoked if false)
        burnable: true, // Always true in Solana (token holders can burn their own tokens)
        pausable: tokenData.pausable // Implemented via freeze authority
      },
      // Add display info for better tracking
      displayInfo: {
        name: tokenData.name,
        symbol: tokenData.symbol,
        description: tokenData.description,
        image: tokenData.logoUrl,
        totalSupply: tokenData.totalSupply.toString(),
        decimals: tokenData.decimals
      }
    };

  } catch (error) {
    console.error('Error creating Solana token:', error);
    
    if (options?.onStepUpdate) {
      options.onStepUpdate('error', 'failed', { 
        error: error instanceof Error ? error.message : 'Unknown error' 
      });
    }
    
    let errorMessage = 'Failed to create token';
    
    if (error instanceof Error) {
      const message = error.message.toLowerCase();
      
      if (message.includes('insufficient')) {
        errorMessage = 'Insufficient SOL balance for transaction fees. Please add SOL to your wallet.';
      } else if (message.includes('rejected') || message.includes('cancelled')) {
        errorMessage = 'Transaction was cancelled in your wallet. Please approve the transaction to continue.';
      } else if (message.includes('network') || message.includes('timeout')) {
        errorMessage = 'Network error. Please check your connection and try again.';
      } else {
        errorMessage = error.message;
      }
    }
    
    return {
      success: false,
      error: errorMessage,
    };
  }
}

// Check if the alternative method should be used
export function shouldUseAlternativeMethod(): boolean {
  // Always use alternative method until the main contract is fixed
  return true;
}

// Get token information using standard Solana methods
export async function getSolanaTokenInfo(mintAddress: string) {
  try {
    const mint = new PublicKey(mintAddress);
    
    // Get mint info
    const mintInfo = await connection.getParsedAccountInfo(mint);
    
    if (!mintInfo.value || !mintInfo.value.data) {
      throw new Error('Token not found');
    }

    const mintData = mintInfo.value.data as ParsedAccountData;
    const info = mintData.parsed.info;
    
    return {
      success: true,
      data: {
        mint: mintAddress,
        decimals: info.decimals,
        supply: info.supply,
        mintAuthority: info.mintAuthority,
        freezeAuthority: info.freezeAuthority,
        isInitialized: info.isInitialized
      }
    };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Failed to get token info'
    };
  }
} 