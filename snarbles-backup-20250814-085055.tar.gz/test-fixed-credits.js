const { createClient } = require('@supabase/supabase-js');

// Use the hardcoded Supabase configuration
const supabaseUrl = 'https://gsrzxzrpxtyjddqkperq.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imdzcnp4enJweHR5amRkcWtwZXJxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDIwMjA0MjQsImV4cCI6MjA1NzU5NjQyNH0.hRXbfLbDtkC2Hbh6ZlVJzT-RsgbogZZ_YGeX6FOcYPI';

const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Simulate the new getCreditsBalance function logic
async function testFixedCreditsBalance() {
  const walletAddress = 'PJEIDDKUOONTJOIV3BLZS7SZSAHCVKNNHTLKMASI6RTYSOZNSDY7MWGZ3M';
  
  console.log('🧪 Testing fixed credits balance function...');
  console.log('Wallet:', walletAddress);
  
  try {
    // Step 1: Use select without .single() to avoid 406 errors
    console.log('\n1️⃣ Checking for existing user profile...');
    const { data, error } = await supabase
      .from('user_profiles')
      .select('credits_balance')
      .eq('wallet_address', walletAddress);

    if (error) {
      console.log('❌ Database error:', error);
      console.log('🔄 Would fall back to demo credits: 10');
      return;
    }

    console.log('✅ Query successful');
    console.log('📊 Data returned:', data);

    // Step 2: Check if profile exists
    if (!data || data.length === 0) {
      console.log('\n2️⃣ No user profile found, attempting to create one...');
      
      try {
        const { data: rpcResult, error: rpcError } = await supabase.rpc('add_credit_transaction', {
          p_wallet_address: walletAddress,
          p_type: 'initial',
          p_amount: 10,
          p_description: 'Initial credits for new user',
          p_transaction_reference: `init_${Date.now()}`
        });

        if (rpcError) {
          console.log('❌ RPC function error:', rpcError);
          console.log('🔄 Would fall back to demo credits: 10');
        } else {
          console.log('✅ RPC function successful:', rpcResult);
          
          // Verify profile was created
          const { data: newProfile, error: checkError } = await supabase
            .from('user_profiles')
            .select('credits_balance')
            .eq('wallet_address', walletAddress);
          
          if (checkError) {
            console.log('❌ Profile verification failed:', checkError);
          } else {
            console.log('✅ Profile created and verified:', newProfile);
          }
        }
      } catch (createError) {
        console.log('❌ Profile creation failed:', createError);
        console.log('🔄 Would fall back to demo credits: 10');
      }
    } else {
      console.log('\n2️⃣ Profile exists! Credits balance:', data[0]?.credits_balance || 0);
    }
    
  } catch (err) {
    console.log('❌ Unexpected error:', err);
    console.log('🔄 Would fall back to demo credits: 10');
  }
}

testFixedCreditsBalance();
