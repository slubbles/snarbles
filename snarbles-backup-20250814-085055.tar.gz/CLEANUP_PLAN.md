# 🧹 Snarbles Codebase Cleanup Plan

## Files to DELETE (Development artifacts)

### 1. Documentation Files to Remove (~149 files)
```bash
# All CAPS .md files (development logs)
*_COMPLETE.md
*_IMPLEMENTATION.md
*_FIX*.md
*_PLAN.md
*_STATUS.md
*_SUMMARY.md
*_GUIDE.md
*_ROADMAP.md
*_CHECKLIST.md
ADMIN_*.md
ALGORAND_*.md
MOBILE_*.md
SOLANA_*.md
CREDITS_*.md
WALLET_*.md
DATABASE_*.md
🎉_*.md
```

### 2. Test/Fix Scripts to Remove (~36 files)
```bash
test-*.js
fix-*.js
check-*.js
*-fix-*.js
verify-database.js
execute-schema-migration.js
simple-fix-test.js
react-hooks-fix-summary.js
```

### 3. SQL Development Files
```bash
fix-*.sql
comprehensive-database-fix.sql
supabase-credit-function.sql
```

### 4. Build/Log Files
```bash
build.log
build-result.log
tsconfig.tsbuildinfo
```

### 5. Development HTML Files
```bash
test-*.html
```

### 6. Development Config Files
```bash
setup-github.md
git-setup.sh
.mcp.json
```

## Files to KEEP (Production code)

### Core Application
- ✅ `app/` - Next.js pages
- ✅ `components/` - React components  
- ✅ `lib/` - Core business logic
- ✅ `public/` - Static assets
- ✅ `styles/` - Styling files
- ✅ `hooks/` - Custom React hooks

### Configuration
- ✅ `package.json` - Dependencies
- ✅ `next.config.js` - Next.js config
- ✅ `tailwind.config.ts` - Tailwind config
- ✅ `tsconfig.json` - TypeScript config
- ✅ `postcss.config.js` - PostCSS config
- ✅ `netlify.toml` - Deployment config
- ✅ `components.json` - UI components config

### Environment & Git
- ✅ `.env.example` - Environment template
- ✅ `.gitignore` - Git ignore rules
- ✅ `.github/` - GitHub workflows
- ✅ `.eslintrc.json` - ESLint config

### Documentation (Clean versions)
- ✅ `README.md` - Main documentation
- ✅ `DEPLOYMENT.md` - If it exists and is clean

### Database (Production ready)
- ✅ `supabase/migrations/` - Database migrations

## 🎯 Result After Cleanup

**Before:** 300+ files
**After:** ~50-60 core files

This will create a **clean, professional open-source repository** ready for contributors.

## 🚀 Execution Plan

1. **Automated cleanup script**
2. **Update README.md** for open source
3. **Add CONTRIBUTING.md**
4. **Add LICENSE**
5. **Clean up package.json** (remove dev dependencies)
6. **Final verification build**
